export const donors = {
  "John Doe": 100,
  "Jane Doe": 200,
  "John Smith": 300,
  "Jane Smith": 400,
  "John Doe2": 500,
  "Jane Doe2": 600,
  "John Smith2": 700,
  "Jane Smith2": 800,
}
